#!/bin/bash
touch log.txt #mi creo il file così stat non mi da errore
while true
do trap "stat -c %Y log.txt > log.txt" SIGUSR1 #il tempo di modifica lo da dall'epoch
done
