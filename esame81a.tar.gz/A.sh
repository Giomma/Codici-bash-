#!/bin/bash
./B.sh &
Bpid=$!
while true 
do read -n 1 -s -p "Press any key to send signal to scriptB "
kill -USR1 $Bpid 
done

